package com.example.VideoGameStore.service;

import com.example.VideoGameStore.database.Connexion;
import com.example.VideoGameStore.entity.VideoGames;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class VideoGamesManager {
    Connexion c=new Connexion();
    public void admission(VideoGames vg) throws SQLException{
        Statement consultation=c.connect().createStatement();
        String chain="INSERT INTO videogames(name, platform, year, genre, publisher, na_sales, eu_sales, jp_sales, other_sales, global_sales) VALUES ('"
                + vg.getName() + "','"
                + vg.getPlatform() + "','"
                + vg.getYear() + "','"
                + vg.getGenre() + "','"
                + vg.getPublisher() + "','"
                + vg.getNa_Sales() + "','"
                + vg.getEu_Sales() + "','"
                + vg.getJp_Sales() + "','"
                + vg.getOther_Sales() + "','"
                + vg.getGlobal_Sales() + "');";
        consultation.executeUpdate(chain);
        consultation.close();
    }

    public List<VideoGames> list() throws SQLException {
        Statement consultation= c.connect().createStatement();
        ResultSet rs=consultation.executeQuery("SELECT * FROM videogames");
        List<VideoGames> list=new ArrayList<>();

        while (rs.next()) {
            VideoGames vg=new VideoGames(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("platform"),
                    rs.getInt("year"),
                    rs.getString("genre"),
                    rs.getString("publisher"),
                    rs.getDouble("na_sales"),
                    rs.getDouble("eu_sales"),
                    rs.getDouble("jp_sales"),
                    rs.getDouble("other_sales"),
                    rs.getDouble("global_sales")
            );
            list.add(vg);
        }
        rs.close();
        consultation.close();
        return list;
    }

    public VideoGames search(int id) throws SQLException {
        Statement consultation= c.connect().createStatement();
        ResultSet rs=consultation.executeQuery("SELECT * FROM videogames WHERE id = " + id);
        VideoGames vg=null;
        if (rs.next()) {
            vg=new VideoGames(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("platform"),
                    rs.getInt("year"),
                    rs.getString("genre"),
                    rs.getString("publisher"),
                    rs.getDouble("na_sales"),
                    rs.getDouble("eu_sales"),
                    rs.getDouble("jp_sales"),
                    rs.getDouble("other_sales"),
                    rs.getDouble("global_sales")
            );
        }
        rs.close();
        consultation.close();
        return vg;
    }

    public void modify(VideoGames vg) throws SQLException {
        Statement consultation= c.connect().createStatement();
        String chain="UPDATE videogames SET "
                + "name = '" + vg.getName() + "', "
                + "platform = '" + vg.getPlatform() + "', "

                + "year = '" + vg.getYear() + "', "
                + "genre = '" + vg.getGenre() + "', "
                + "publisher = '" + vg.getPublisher() + "', "
                + "na_sales = '" + vg.getNa_Sales() + "', "
                + "eu_sales = '" + vg.getEu_Sales() + "', "
                + "jp_sales = '" + vg.getJp_Sales() + "', "
                + "other_sales = '" + vg.getOther_Sales() + "', "
                + "global_sales = '" + vg.getGlobal_Sales() + "' "
                + "WHERE id = " + vg.getId();
        consultation.executeUpdate(chain);
        consultation.close();
    }

    public void eliminate(int id) throws SQLException {
        Statement consultation= c.connect().createStatement();
        consultation.executeUpdate("DELETE FROM videogames WHERE id = " +id);
        consultation.close();
    }
}