package com.example.VideoGameStore.entity;

public class VideoGames {
    private Long id;
    private String name;
    private String platform;
    private int year;
    private String genre;
    private String publisher;
    private double na_Sales;
    private double eu_Sales;
    private double jp_Sales;
    private double other_Sales;
    private double global_Sales;

    public VideoGames(){

    }

    public VideoGames(String name, String platform, int year, String genre, String publisher, double na_Sales, double eu_Sales, double jp_Sales, double other_Sales, double global_Sales) {
        this.name = name;
        this.platform = platform;
        this.year = year;
        this.genre = genre;
        this.publisher = publisher;
        this.na_Sales = na_Sales;
        this.eu_Sales = eu_Sales;
        this.jp_Sales = jp_Sales;
        this.other_Sales = other_Sales;
        this.global_Sales = global_Sales;
    }

    public VideoGames(Long id, String name, String platform, int year, String genre, String publisher, double na_Sales, double eu_Sales, double jp_Sales, double other_Sales, double global_Sales) {
        this.id = id;
        this.name = name;
        this.platform = platform;
        this.year = year;
        this.genre = genre;
        this.publisher = publisher;
        this.na_Sales = na_Sales;
        this.eu_Sales = eu_Sales;
        this.jp_Sales = jp_Sales;
        this.other_Sales = other_Sales;
        this.global_Sales = global_Sales;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public double getNa_Sales() {
        return na_Sales;
    }

    public void setNa_Sales(double na_Sales) {
        this.na_Sales = na_Sales;
    }

    public double getEu_Sales() {
        return eu_Sales;
    }

    public void setEu_Sales(double eu_Sales) {
        this.eu_Sales = eu_Sales;
    }

    public double getJp_Sales() {
        return jp_Sales;
    }

    public void setJp_Sales(double jp_Sales) {
        this.jp_Sales = jp_Sales;
    }

    public double getOther_Sales() {
        return other_Sales;
    }

    public void setOther_Sales(double other_Sales) {
        this.other_Sales = other_Sales;
    }

    public double getGlobal_Sales() {
        return global_Sales;
    }

    public void setGlobal_Sales(double global_Sales) {
        this.global_Sales = global_Sales;
    }

    @Override
    public String toString() {

        return String.format("%-4d %-20s %-20s %-15s %-25s %-35s",
                id,
                name,
                platform,
                year,
                genre,
                publisher,
                na_Sales,
                eu_Sales,
                jp_Sales,
                other_Sales,
                global_Sales);
    }
}