package com.example.VideoGameStore.controller;

import com.example.VideoGameStore.entity.VideoGames;
import com.example.VideoGameStore.service.VideoGamesManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
@RequestMapping("/videogames")
public class ControllerVideoGames {
    VideoGamesManager vgm=new VideoGamesManager();

    @GetMapping("/")
    public String crud(Model model) {
        String finalvalue="./videogames/listvideogames";
        try {
            model.addAttribute("vgames", vgm.list());
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVideoGames.class.getName()).log(Level.SEVERE, null, ex);
            finalvalue="Mistake";
        }
        return finalvalue;
    }

    @GetMapping("/admission")
    public String greetingForm(Model model) {
        model.addAttribute("videogames", new VideoGames());
        return "./videogames/admissionvideogames";
    }

    @PostMapping("/admission")
    public String greetingSubmit(@ModelAttribute VideoGames videogames, Model model) {
        String finalvalue="redirect:/videogames/";
        try {
            vgm.admission(videogames);
            try {
                model.addAttribute("vgames", vgm.list());
            } catch (SQLException ex) {
                Logger.getLogger(ControllerVideoGames.class.getName()).log(Level.SEVERE, null, ex);
                finalvalue="Mistake";
            }
        } catch (SQLException ex) {
            finalvalue="Mistake";
        }
        return finalvalue;
    }

    @GetMapping("/eliminate")
    public String SubmitB (@RequestParam("videogamescode") int id, Model model){
        String finalvalue="redirect:/videogames/";
        try {
            vgm.eliminate(id);
            model.addAttribute("vgames", vgm.list());
        } catch (SQLException ex) {
            finalvalue="Mistake";
        }
        return finalvalue;
    }

    @GetMapping("/modify")
    public String modify(@RequestParam ("videogamescode") int id, Model model){
        String finalvalue="./videogames/modifyvideogames";
        try {
            model.addAttribute("videogames", vgm.search(id));
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVideoGames.class.getName()).log(Level.SEVERE, null, ex);
            finalvalue="Mistake";
        }
        return finalvalue;
    }

    @PostMapping("/modify")
    public String modifyDataBase (@ModelAttribute VideoGames videogames, Model model){
        String finalvalue="redirect:/videogames/";
        try {
            vgm.modify(videogames);
            model.addAttribute("vgames", vgm.list());
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVideoGames.class.getName()).log(Level.SEVERE, null, ex);
            finalvalue="Mistake";
        }
        return finalvalue;
    }
}