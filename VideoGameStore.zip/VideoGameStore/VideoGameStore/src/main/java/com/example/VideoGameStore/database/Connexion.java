package com.example.VideoGameStore.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connexion {
    String url="jdbc:mysql://localhost:3306/video_game";
    String user="root";
    String pass="root";
    Connection c;

    public Connection connect() throws SQLException {
        c=DriverManager.getConnection(url, user, pass);
        return c;
    }
}